


var slideIndex = 1;
showSlides(slideIndex);
 var currentIndex = 0;
 var time=0;
var pre = 0;
function currentSlide(currentIndex) {
  showSlides(slideIndex = currentIndex);
}

function showSlides(currentIndex) {
  var i;
 let slides = document.getElementsByClassName("slider-image")[0].querySelectorAll("img");
  let dots = document.getElementsByClassName("nav");
  for (i = 0; i < slides.length; i++) {
      slides[i].style.opacity = "0";  
  }

  slides[slideIndex-1].style.opacity = "1";
      dots[slideIndex-1].querySelector("input").checked="true";

if(slideIndex < slides.length)
{
slideIndex++;
}
else
{
slideIndex = 1;
}

time = setTimeout(showSlides, 3000);
	
}


document.getElementsByClassName("slider-image")[0].onmouseover=()=>{
  console.log("yes");
  clearTimeout(time);
}

document.getElementsByClassName("slider-image")[0].onmouseout=()=>{
  console.log("no");
    clearTimeout(time);
  showSlides(slideIndex);
}