var content = document.querySelector(".content").clientHeight;
var dynamic = document.querySelector(".dynamic");
var btlImg = document.querySelector(".btl_img");
let finalHeight = content - 179;

if (content > 179) {
  btlImg.style.margin= `30px 50px 30px 50px`;
  dynamic.style.height = `${finalHeight}px`;
}

