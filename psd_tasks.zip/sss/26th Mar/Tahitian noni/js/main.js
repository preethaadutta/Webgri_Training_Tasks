/*

var item = document.getElementsByClassName("items");
var content= document.getElementsByClassName("content");


console.log(item);
console.log(content);

for(i=0; i<content.length; i++){
	content[i].addEventListener("click",function col(n){  
	  this.classList.toggle("active");
	this.style.transtion= "1s";
	this.style.height="110px";
	  
		
	});
	
	content[i].style.transtion = "1s";
	content[i].style.height="50px";
	content[i].classList.remove("active");
}

*/



var content = document.getElementsByClassName("content");

function col(n){
for(var i = 0; i< content.length; i++)
{
content[i].style.transtion= "1s";
content[i].style.height="0px";
content[i].classList.remove("active");
}

content[n].style.transtion= "1s";
content[n].style.height= "110px";
content[n].classList.add("active");
}
