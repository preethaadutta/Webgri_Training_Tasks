var navigate = document.getElementsByTagName('prev');
var slide = document.getElementsByTagName('slide');
let preBtn = document.getElementById(prev);
var nxtBtn = document.getElementById(next);
var l=0;





navigate[1].onclick = () => {
l++;
for(var i of slide)
{
if(l==0){i.style.left="0px";}
if(l==1){i.style.left="-910px";}
if(l==2){i.style.left="-1820px";}
if(l==3){i.style.left="-2366px";}

if(l>3){l=3;}console.log(l);
console.log(i);


if(l==0)
{
navigate[0].classList.add("disabled");
}
else{
navigate[0].classList.remove("disabled");
}

if(l>=3)
{
navigate[1].classList.add("disabled");
}
else{
navigate[1].classList.remove("disabled");
}



}
}

navigate[0].onclick = () => {
l--;
for(var i of slide)
{
if(l==0){i.style.left="0px";}
if(l==1){i.style.left="-546px";}
if(l==2){i.style.left="-1456px";}
if(l<0){l=0;}console.log(l);
console.log(i);



if(l==0)
{
navigate[0].classList.add("disabled");
}
else{
navigate[0].classList.remove("disabled");
}

if(l>=3)
{
navigate[1].classList.add("disabled");
}
else{
navigate[1].classList.remove("disabled");
}



}
}