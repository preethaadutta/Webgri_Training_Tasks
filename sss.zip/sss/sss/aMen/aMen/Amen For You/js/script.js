var arrow = document.getElementsByTagName('arrow');
var slide = document.getElementsByTagName('slide');
let preBtn = document.getElementById('prev');
var nxtBtn = document.getElementById('next');
var l=0;





arrow[1].onclick = () => {
l++;
for(var i of slide)
{
if(l==0){i.style.left="0px";}
if(l==1){i.style.left="-640px";}
if(l==2){i.style.left="-1280px";}
if(l==3){i.style.left="-1664px";}
if(l>3){l=3;}console.log(l);



if(l==0)
{
arrow[0].classList.add("disabled");
}
else{
arrow[0].classList.remove("disabled");
}

if(l>=3)
{
arrow[1].classList.add("disabled");
}
else{
arrow[1].classList.remove("disabled");
}



}
}

arrow[0].onclick = () => {
l--;
for(var i of slide)
{
if(l==0){i.style.left="0px";}
if(l==1){i.style.left="-384px";}
if(l==2){i.style.left="-1024px";}
if(l<0){l=0;}console.log(l);




if(l==0)
{
arrow[0].classList.add("disabled");
}
else{
arrow[0].classList.remove("disabled");
}

if(l>=3)
{
arrow[1].classList.add("disabled");
}
else{
arrow[1].classList.remove("disabled");
}



}
};






let onslidee = false;

window.addEventListener("load", () => {
   autoslidee();

   const dots = document.querySelectorAll(".carousel_dot");
   for (let i = 0; i < dots.length; i++) {
      dots[i].addEventListener("click", () => slidee(i));
   }

   const buttonPrev = document.querySelector(".carousel_button__prev");
   const buttonNext = document.querySelector(".carousel_button__next");
   buttonPrev.addEventListener("click", () => slidee(getItemActiveIndex() - 1));
   buttonNext.addEventListener("click", () => slidee(getItemActiveIndex() + 1));
})

function autoslidee() {
   time=setInterval(() => {
      slidee(getItemActiveIndex() + 1);
   }, 6000);
}

function slidee(toIndex) {
   if (onslidee)
      return;
   onslidee = true;

   const itemsArray = Array.from(document.querySelectorAll(".carousel_item"));
   const itemActive = document.querySelector(".carousel_item__active");
   const itemActiveIndex = itemsArray.indexOf(itemActive);
   let newItemActive = null;

   if (toIndex > itemActiveIndex) {
      if (toIndex >= itemsArray.length) {
         toIndex = 0;
      }

      newItemActive = itemsArray[toIndex];

      newItemActive.classList.add("carousel_item__pos_next");
      setTimeout(() => {
         newItemActive.classList.add("carousel_item__next");
         itemActive.classList.add("carousel_item__next");
      }, 20);
   } else {
      if (toIndex < 0) {
         toIndex = itemsArray.length - 1;
      }

      newItemActive = itemsArray[toIndex];
      newItemActive.classList.add("carousel_item__pos_prev");
      setTimeout(() => {
         newItemActive.classList.add("carousel_item__prev");
         itemActive.classList.add("carousel_item__prev");
      }, 20);
   }

   newItemActive.addEventListener("transitionend", () => {
      itemActive.className = "carousel_item";
      newItemActive.className = "carousel_item carousel_item__active";
      onslidee = false;
   }, {
      once: true
   });

   slideeIndicator(toIndex);
}

function getItemActiveIndex() {
   const itemsArray = Array.from(document.querySelectorAll(".carousel_item"));
   const itemActive = document.querySelector(".carousel_item__active");
   const itemActiveIndex = itemsArray.indexOf(itemActive);
   return itemActiveIndex;
}

function slideeIndicator(toIndex) {
   const dots = document.querySelectorAll(".carousel_dot");
   const dotActive = document.querySelector(".carousel_dot__active");
   const newDotActive = dots[toIndex];

   dotActive.classList.remove("carousel_dot__active");
   newDotActive.classList.add("carousel_dot__active");
}






function offtr(){
const main= document.querySelector("#main");
main.classList.add("carousel__fade")
      setTimeout(() => {
main.classList.remove("carousel__fade")
      }, 1500);


}



function stopSlide(){
clearInterval(time);
}
