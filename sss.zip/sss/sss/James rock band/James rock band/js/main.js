
let latestbtn = document.getElementById("latest");
let jazzbtn = document.getElementById("jazz");
let metalbtn = document.getElementById("metal");
let rockbtn = document.getElementById("rock");


let latestimg = document.getElementById("latest-image");
let jazzimg = document.getElementById("jazz-image");
let metalimg = document.getElementById("metal-image");
let rockimg = document.getElementById("rock-image");


//image card banner section

function Latest(){
	if(!latestbtn.classList.contains('active')){
		latestbtn.classList.add('active');
		latestimg.classList.add('show-active');
		

	
		jazzbtn.classList.remove('active');
		jazzimg.classList.remove('show-active');
		metalbtn.classList.remove('active');
		metalimg.classList.remove('show-active');
		rockbtn.classList.remove('active');
		rockimg.classList.remove('show-active');
		
	}


console.log("latest");
}


function Jazz(){
	if(!jazzbtn.classList.contains('active')){
		jazzbtn.classList.add('active');
		jazzimg.classList.add('show-active');
		

		
		latestbtn.classList.remove('active');
		latestimg.classList.remove('show-active');
		metalbtn.classList.remove('active');
		metalimg.classList.remove('show-active');
		rockbtn.classList.remove('active');
		rockimg.classList.remove('show-active');
		
	}
console.log("jazz");
}




function Metal(){
	if(!metalbtn.classList.contains('active')){
		metalbtn.classList.add('active');
		metalimg.classList.add('show-active');

		latestbtn.classList.remove('active');
		latestimg.classList.remove('show-active');
		jazzbtn.classList.remove('active');
		jazzimg.classList.remove('show-active');
		rockbtn.classList.remove('active');
		rockimg.classList.remove('show-active');
	}
console.log("Metal");
}


function Rock(){
	if(!rockbtn.classList.contains('active')){
		rockbtn.classList.add('active');
		rockimg.classList.add('show-active');

		latestbtn.classList.remove('active');
		latestimg.classList.remove('show-active');
		jazzbtn.classList.remove('active');
		jazzimg.classList.remove('show-active');
		metalbtn.classList.remove('active');
		metalimg.classList.remove('show-active');
	
	}
console.log("rock");
}


//top banner section

let banner1 = document.getElementById("banner1");
let banner2 = document.getElementById("banner2");
let banner3 = document.getElementById("banner3");
let banner4 = document.getElementById("banner4");




function slideOn1(){
	banner1.classList.add('show-active1');
	
	
	banner2.classList.remove('show-active1');
	banner3.classList.remove('show-active1');
	banner4.classList.remove('show-active1')
}


function slideOn2(){
	banner2.classList.add('show-active1');

	banner1.classList.remove('show-active1');
	banner3.classList.remove('show-active1');
	banner4.classList.remove('show-active1')
	
}

function slideOn3(){
	banner3.classList.add('show-active1');

	banner1.classList.remove('show-active1');
	banner2.classList.remove('show-active1');
	banner4.classList.remove('show-active1')
}

function slideOn4(){
	banner4.classList.add('show-active1');

	banner1.classList.remove('show-active1');
	banner2.classList.remove('show-active1');
	banner3.classList.remove('show-active1')
}




//top notificarion section


let news = document.getElementById("btn1");
let reviews = document.getElementById("btn2");
let interviews = document.getElementById("btn3");

let newscontent = document.getElementById("news");
let reviewscontent = document.getElementById("reviews");
let interviewscontent = document.getElementById("interviews");


function News(){
	if (!news.classList.contains("active")){
	   news.classList.add('active');
	   newscontent.classList.add('show-active2');
	

	 	
	   reviews.classList.remove('active');
	   reviewscontent.classList.remove('show-active2');
	   interviews.classList.remove('active');
 	   interviewscontent.classList.remove('show-active2');
	}
}


function Reviews(){
	if (!reviews.classList.contains("active")){
	   reviews.classList.add('active');
	   reviewscontent.classList.add('show-active2');


	
	  news.classList.remove('active');
	   newscontent.classList.remove('show-active2');
	   interviews.classList.remove('active');
 	   interviewscontent.classList.remove('show-active2');
	}
}

function Interviews(){
	if (!interviews.classList.contains("active")){
	  interviews.classList.add('active');
	  interviewscontent.classList.add('show-active2');
		
	
	
	  news.classList.remove('active');
	   newscontent.classList.remove('show-active2');
	   reviews.classList.remove('active');
	   reviewscontent.classList.remove('show-active2');
	  
	}
}

